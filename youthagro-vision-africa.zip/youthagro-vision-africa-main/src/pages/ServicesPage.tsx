import Header from "@/components/Header";
import Services from "@/components/Services";
import Technology from "@/components/Technology";
import Footer from "@/components/Footer";

const ServicesPage = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-20">
        <Services />
        <Technology />
      </main>
      <Footer />
    </div>
  );
};

export default ServicesPage;
