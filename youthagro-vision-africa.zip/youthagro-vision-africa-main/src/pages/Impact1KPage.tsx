import Header from "@/components/Header";
import Impact1K from "@/components/Impact1K";
import Footer from "@/components/Footer";

const Impact1KPage = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-20">
        <Impact1K />
      </main>
      <Footer />
    </div>
  );
};

export default Impact1KPage;
