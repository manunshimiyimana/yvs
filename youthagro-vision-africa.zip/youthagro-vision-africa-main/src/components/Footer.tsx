import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";
import yavfLogo from "@/assets/yavf-logo.jpg";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Logo and Description */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <img src={yavfLogo} alt="Youth Agro Visionary Farm Logo" className="h-10 w-10 rounded-lg object-cover" />
              <div>
                <h3 className="text-sm font-bold">Youth Agro Visionary Farm Ltd</h3>
              </div>
            </div>
            <p className="text-primary-foreground/80 mb-4 text-sm leading-relaxed">
              Empowering young Rwandans through sustainable farming and climate-smart practices.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-3">
              <a href="#" className="p-1.5 bg-primary-foreground/10 rounded-lg hover:bg-primary-foreground/20 transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="https://twitter.com/NSENGIYUMV71627" target="_blank" rel="noopener noreferrer" className="p-1.5 bg-primary-foreground/10 rounded-lg hover:bg-primary-foreground/20 transition-colors">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="p-1.5 bg-primary-foreground/10 rounded-lg hover:bg-primary-foreground/20 transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="p-1.5 bg-primary-foreground/10 rounded-lg hover:bg-primary-foreground/20 transition-colors">
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-3 text-sm">Quick Links</h4>
            <ul className="space-y-1.5 text-sm">
              <li><Link to="/about" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">About Us</Link></li>
              <li><Link to="/services" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Our Services</Link></li>
              <li><Link to="/impact1k" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Impact1K+</Link></li>
              <li><Link to="/contact" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold mb-3 text-sm">Our Focus</h4>
            <ul className="space-y-1.5 text-sm">
              <li className="text-primary-foreground/80">Sustainable Farming</li>
              <li className="text-primary-foreground/80">Youth Training</li>
              <li className="text-primary-foreground/80">Agroforestry</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 mt-6 pt-6 text-center">
          <p className="text-primary-foreground/80 text-xs">
            © {currentYear} Youth Agro Visionary Farm Ltd. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;