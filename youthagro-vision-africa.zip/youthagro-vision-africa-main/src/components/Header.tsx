import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import yavfLogo from "@/assets/yavf-logo-new.jpg";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "SMART HINGA PROGRAM", href: "/services" },
    { name: "IMPACT1K+ PROGRAM", href: "/impact1k" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <header className="fixed top-0 w-full bg-background/95 backdrop-blur-sm border-b border-border z-50">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img src={yavfLogo} alt="Youth Agro Visionary Farm Logo" className="h-24 w-24 rounded-lg object-cover" />
            <div>
              <h1 className="text-lg font-bold text-foreground leading-tight">Youth Agro Visionary Farm Ltd</h1>
              <p className="text-sm text-muted-foreground">(Impact1K+)</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="bg-forest-green text-white hover:bg-forest-green-light transition-all duration-300 font-semibold px-4 py-2 rounded-md shadow-soft hover:shadow-strong hover:scale-105"
              >
                {item.name}
              </Link>
            ))}
            <Link to="/contact">
              <Button variant="hero" size="sm">
                Get Started
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col space-y-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className="bg-forest-green text-white hover:bg-forest-green-light transition-all duration-300 font-semibold px-4 py-3 rounded-md shadow-soft hover:shadow-strong text-center"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <Link to="/contact" onClick={() => setIsMenuOpen(false)}>
                <Button variant="hero" size="sm" className="w-fit">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;