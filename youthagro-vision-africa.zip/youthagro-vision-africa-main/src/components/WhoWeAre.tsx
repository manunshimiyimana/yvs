import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";

const WhoWeAre = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('who-we-are');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      title: "Climate-Smart Agribusiness Projects",
      description: "Implementing sustainable farming techniques that increase productivity, enhance resilience to climate change, and reduce environmental footprints."
    },
    {
      title: "Agribusiness Development & Incubation",
      description: "From ideation to harvest and market, we offer end-to-end support including business planning, financial modeling, market linkage, and mentorship."
    },
    {
      title: "Regenerative Agriculture Consulting",
      description: "We advise on practices that restore soil health, improve water management, and increase biodiversity for long-term productivity."
    },
    {
      title: "Impact Creation & Community Programs",
      description: "We design and manage programs that foster youth inclusion, knowledge transfer, and shared value creation for community well-being."
    }
  ];

  return (
    <section id="who-we-are" className="section-padding bg-gradient-earth">
      <div className="container mx-auto container-padding">
        <div className={`text-center max-w-5xl mx-auto ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <Badge variant="success" className="text-sm font-medium mb-4 inline-block">
            Who We Are
          </Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Youth Agro Visionary <span className="gradient-text">Farm Ltd.</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-6">
            Welcome to Youth Agro Visionary Farm Ltd., an Agribusiness Development Service Centre driven by a core mission: 
            to contribute to community well-being through holistic green and agribusiness development services.
          </p>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-12">
            We believe the future of agriculture is regenerative, innovative, and youth-led. We partner with businesses and 
            communities to turn environmental and economic challenges into scalable, impactful opportunities. From climate-smart 
            projects to end-to-end business development, we are here to create impact where it matters most.
          </p>

          {/* Core Services */}
          <div className="mt-16">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Driving <span className="gradient-text">Regenerative Innovation</span>
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              We provide the expertise and services to build resilient and profitable agribusinesses for a new generation.
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 mt-8">
              {services.map((service, index) => (
                <div 
                  key={index}
                  className="glass-card p-6 rounded-xl text-left hover-lift"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <h4 className="text-xl font-semibold text-foreground mb-3">{service.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhoWeAre;
