import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Users, CheckCircle, TrendingUp, Smartphone, Database } from "lucide-react";
import { useState, useEffect } from "react";

const About = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('about');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Brain,
      title: "Climate-Smart Agribusiness Projects",
      description: "Implementing sustainable farming techniques that increase productivity, enhance resilience to climate change, and reduce environmental footprints. We help you future-proof your operations."
    },
    {
      icon: TrendingUp,
      title: "Agribusiness Development & Incubation",
      description: "From ideation to harvest and market, we offer end-to-end support. This includes business planning, financial modeling, market linkage, and mentorship for aspiring and existing agri-entrepreneurs."
    },
    {
      icon: CheckCircle,
      title: "Regenerative Agriculture Consulting",
      description: "Go beyond sustainability. We advise on practices that restore soil health, improve water management, and increase biodiversity, making your land and business more productive for generations to come."
    },
    {
      icon: Users,
      title: "Impact Creation & Community Programs",
      description: "Our work is rooted in community well-being. We design and manage programs that foster youth inclusion, knowledge transfer, and shared value creation, ensuring growth benefits everyone."
    }
  ];

  return (
    <section id="about" className="section-padding bg-gradient-earth">
      <div className="container mx-auto container-padding">
        <div className="text-center mb-16">
          <div className={`${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <Badge variant="success" className="text-sm font-medium mb-4 inline-block">
              Our Core Services
            </Badge>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
              Driving Regenerative <span className="gradient-text">Innovation</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-4xl mx-auto text-balance leading-relaxed">
              We provide the expertise and services to build resilient and profitable agribusinesses for a new generation.
            </p>
          </div>
        </div>

        <div className={`grid grid-cols-1 md:grid-cols-2 gap-8 mb-16 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
          {services.map((service, index) => (
            <Card key={index} className="hover-lift group">
              <CardHeader>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="p-4 bg-gradient-hero rounded-xl group-hover:scale-110 transition-transform">
                    <service.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl font-bold text-foreground">{service.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className={`glass-card rounded-2xl p-8 lg:p-12 shadow-strong border border-border/50 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-6 text-balance">
                Technology That Transforms <span className="gradient-text">Livelihoods</span>
              </h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                At the heart of our work is a belief that technology can unlock the full potential of Rwanda's 
                agricultural sector. Through advanced AI tools, IoT sensors, real-time insights, and farmer-focused 
                digital platforms, we help farmers increase productivity, reduce losses, adapt to climate change, 
                and earn more from their hard work.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Whether you're looking to monitor your crops, access hyper-local weather data, automate irrigation, 
                detect diseases early, or connect directly with buyers, we provide the tools and support you need 
                to grow smarter and succeed.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">AI-Powered</span>
                <span className="px-3 py-1 bg-accent/10 text-accent rounded-full text-sm font-medium">IoT Enabled</span>
                <span className="px-3 py-1 bg-secondary/30 text-secondary-foreground rounded-full text-sm font-medium">Data-Driven</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 glass-card rounded-xl hover-lift">
                <Brain className="h-8 w-8 text-primary mx-auto mb-3" />
                <div className="text-2xl font-bold text-foreground mb-1">95%</div>
                <div className="text-sm text-muted-foreground">Disease Detection</div>
                <div className="text-xs text-muted-foreground/60">Success rate</div>
              </div>
              
              <div className="text-center p-6 glass-card rounded-xl hover-lift">
                <TrendingUp className="h-8 w-8 text-accent mx-auto mb-3" />
                <div className="text-2xl font-bold text-foreground mb-1">25%</div>
                <div className="text-sm text-muted-foreground">Higher Income</div>
                <div className="text-xs text-muted-foreground/60">Through market access</div>
              </div>
              
              <div className="text-center p-6 glass-card rounded-xl hover-lift">
                <Smartphone className="h-8 w-8 text-secondary-foreground mx-auto mb-3" />
                <div className="text-2xl font-bold text-foreground mb-1">100%</div>
                <div className="text-sm text-muted-foreground">Accessible</div>
                <div className="text-xs text-muted-foreground/60">USSD & mobile app</div>
              </div>
              
              <div className="text-center p-6 glass-card rounded-xl hover-lift">
                <Database className="h-8 w-8 text-forest-green mx-auto mb-3" />
                <div className="text-2xl font-bold text-foreground mb-1">Fair</div>
                <div className="text-sm text-muted-foreground">Data Economy</div>
                <div className="text-xs text-muted-foreground/60">Revenue sharing</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;